package com.cg.crs.beans;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.Select;

public class RegristrationPage {
	
	@FindBy(how=How.NAME,name="txtFN")
	private WebElement firstName;
	
	@FindBy(how=How.NAME,name="txtLN")
	private WebElement lastName;
	
	@FindBy(how=How.NAME,name="Email")
	private WebElement email;
	
	@FindBy(how=How.NAME,name="Phone")
	private WebElement contactNo;
	
	@FindBy(name="size")
	List<WebElement> peopleAttending;
	
	@FindBy(how=How.NAME,name="Address")
	private WebElement address1;
	
	@FindBy(how=How.NAME,name="Address2")
	private WebElement address2;
	
	@FindBy(name="city")
	List<WebElement> city;
	
	@FindBy(name="state")
	List<WebElement> state;
	
	@FindBy(name="memberStatus")
	List<WebElement> memberStatus;
	
	@FindBy(xpath="/html/body/form/table/tbody/tr[14]/td/a")
	WebElement nextbtn;
	
	@FindBy(xpath="//*[@id=\"txtCardholderName\"]")
	WebElement holderName;
	
	@FindBy(xpath="//*[@id=\"txtDebit\"]")
	WebElement holderNumber;
	
	@FindBy(xpath="//*[@id=\"txtCvv\"]")
	WebElement cvv;
	
	@FindBy(xpath="//*[@id=\"txtMonth\"]")
	WebElement month;
	
	@FindBy(xpath="//*[@id=\"txtYear\"]")
	WebElement year;
	
	@FindBy(xpath="//*[@id=\"btnPayment\"]")
	WebElement paymentbtn;
	
	public void clickOnNext()
	{
		nextbtn.click();
	}
	
	public void paymentBtn()
	{
		paymentbtn.click();
	}
	
	public RegristrationPage() {
		super();
	}

	public WebElement getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName.sendKeys(firstName);
	}

	public WebElement getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName.sendKeys(lastName);
	}

	public WebElement getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email.sendKeys(email);
	}

	public String getContactNo() {
		return contactNo.getAttribute("value");
	}

	public void setContactNo(String contactNo) {
		this.contactNo.sendKeys(contactNo);
	}

	public List<WebElement> getPeopleAttending() {
		return peopleAttending;
	}

	public void setPeopleAttending(String element) {
		Select selects = new Select(this.peopleAttending.get(0));
	    selects.selectByVisibleText(element);
	}

	public WebElement getAddress1() {
		return address1;
	}

	public void setAddress1(String element) {
		this.address1.sendKeys(element);
	}

	public WebElement getAddress2() {
		return address2;
	}

	public void setAddress2(String address2) {
		this.address2.sendKeys(address2);
	}

	public List<WebElement> getCity() {
		return city;
	}

	public void setCity(String element) {
		Select selects = new Select(this.city.get(0));
	    selects.selectByVisibleText(element);
	}

	public List<WebElement> getState() {
		return state;
	}

	public void setState(String element) {
		Select selects = new Select(this.state.get(0));
	    selects.selectByVisibleText(element);
	}

	public List<WebElement> getMemberStatus() {
		return memberStatus;
	}

	public void setMemberStatus(String element) {
		for(WebElement elements : memberStatus)
		{
			if(elements.getAttribute("value").contains(element))
			{
			elements.click();
			}
		}
	}

	public WebElement getHolderName() {
		return holderName;
	}

	public void setHolderName(String holderName) {
		this.holderName.sendKeys(holderName);
	}

	public WebElement getHolderNumber() {
		return holderNumber;
	}

	public void setHolderNumber(String holderNumber) {
		this.holderNumber.sendKeys(holderNumber);
	}

	public WebElement getMonth() {
		return month;
	}

	public void setMonth(String month) {
		this.month.sendKeys(month);
	}

	public WebElement getYear() {
		return year;
	}

	public void setYear(String year) {
		this.year.sendKeys(year);
	}

	public WebElement getCvv() {
		return cvv;
	}

	public void setCvv(String cvv) {
		this.cvv.sendKeys(cvv);
	}
	
	
	
}
