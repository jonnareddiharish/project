package com.cg.crs.stepdefinations;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.crs.beans.RegristrationPage;

import cucumber.api.PendingException;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class RegristerConferenceStepDefination {
	
	private WebDriver driver;
	private RegristrationPage page;
	
	@Before
	public void setupStepEnv()
	{
		System.setProperty("webdriver.chrome.driver", "D:\\chrome_driver\\chromedriver.exe");		
	}
	
	@Given("^user is on regristration homepage$")
	public void user_is_on_regristration_homepage() throws Throwable {
		driver= new ChromeDriver();
		driver.get("D:\\MPT Set 1\\ConferenceRegistartion.html");		
		page=new RegristrationPage();
		PageFactory.initElements(driver, page);
	}

	@When("^When user is on regristration homepage$")
	public void when_user_is_on_regristration_homepage() throws Throwable {
	    
	}

	@Then("^regristration Page should load with title 'Conference Registration'$")
	public void regristration_Page_should_load_with_title_Conference_Registration() throws Throwable {
		String expectedMessage="Conference Registartion";
		String actualMessage=driver.getTitle();
		Assert.assertEquals(expectedMessage, actualMessage);
	}

	@When("^user click on next in homepage without giving First Name$")
	public void user_click_on_next_in_homepage_without_giving_First_Name() throws Throwable {
	   page.clickOnNext();
	  
	}

	@Then("^'Please fill the First Name' message should display$")
	public void please_fill_the_First_Name_message_should_display() throws Throwable {
		 String expectedMessage="Please fill the First Name";
			String actualMessage=driver.switchTo().alert().getText();
			Assert.assertEquals(expectedMessage, actualMessage);
			Thread.sleep(2000);
			driver.switchTo().alert().dismiss();
	}

	@When("^user click on next in homepage without giving Last Name$")
	public void user_click_on_next_in_homepage_without_giving_Last_Name() throws Throwable {
	    page.setFirstName("jonny");
	    page.clickOnNext();
	}

	@Then("^'Please fill the Last Name' message should display$")
	public void please_fill_the_Last_Name_message_should_display() throws Throwable {
		 String expectedMessage="Please fill the Last Name";
			String actualMessage=driver.switchTo().alert().getText();
			Assert.assertEquals(expectedMessage, actualMessage);
			Thread.sleep(2000);
			driver.switchTo().alert().dismiss();
	}

	@When("^user click on next in homepage without giving Email$")
	public void user_click_on_next_in_homepage_without_giving_Email() throws Throwable {
	    page.setLastName("vicky");
	    page.clickOnNext();
	}

	@Then("^'Please fill the Email' message should display$")
	public void please_fill_the_Email_message_should_display() throws Throwable {
		String expectedMessage="Please fill the Email";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		Thread.sleep(2000);
		driver.switchTo().alert().dismiss();
	}

	@When("^user click on next in homepage without giving Contact number$")
	public void user_click_on_next_in_homepage_without_giving_Contact_number() throws Throwable {
	   page.setEmail("jonny@gmail.com");
	   page.clickOnNext();
	}

	@Then("^'Please fill the Contact No\\.' message should display$")
	public void please_fill_the_Contact_No_message_should_display() throws Throwable {
		String expectedMessage="Please fill the Contact No.";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		Thread.sleep(2000);
		driver.switchTo().alert().dismiss();
	}

	@When("^user click on next in homepage without giving valid Contact number$")
	public void user_click_on_next_in_homepage_without_giving_valid_Contact_number() throws Throwable {
	  page.setContactNo("7789");
	  page.clickOnNext();
	}

	@Then("^'Please enter valid Contact no\\.' message should display$")
	public void please_enter_valid_Contact_no_message_should_display() throws Throwable {
		String expectedMessage="Please enter valid Contact no.";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		Thread.sleep(2000);
		driver.switchTo().alert().dismiss();
	}

	@When("^When user click on next in homepage without giving Number of people attending$")
	public void when_user_click_on_next_in_homepage_without_giving_Number_of_people_attending() throws Throwable {
	    page.setContactNo("543210");
	    page.clickOnNext();
	}

	@Then("^'Please fill the Number of people attending' message should display$")
	public void please_fill_the_Number_of_people_attending_message_should_display() throws Throwable {
		String expectedMessage="Please fill the Number of people attending";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		Thread.sleep(2000);
		driver.switchTo().alert().dismiss();
	}

	@When("^When user click on next in homepage without giving Building Name & Room no$")
	public void when_user_click_on_next_in_homepage_without_giving_Building_Name_Room_no() throws Throwable {
	   page.setPeopleAttending("3");
	   page.clickOnNext();
	}

	@Then("^'Please fill the Building & Room No' message should display$")
	public void please_fill_the_Building_Room_No_message_should_display() throws Throwable {
		String expectedMessage="Please fill the Building & Room No";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		Thread.sleep(2000);
		driver.switchTo().alert().dismiss();
	}

	@When("^When user click on next in homepage without giving Area Name$")
	public void when_user_click_on_next_in_homepage_without_giving_Area_Name() throws Throwable {
	   page.setAddress1("place name");
	   page.clickOnNext();
	}

	@Then("^'Please fill the Area name' message should display$")
	public void please_fill_the_Area_name_message_should_display() throws Throwable {
		String expectedMessage="Please fill the Area name";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		Thread.sleep(2000);
		driver.switchTo().alert().dismiss();
	}

	@When("^When user click on next in homepage without selecting City Name$")
	public void when_user_click_on_next_in_homepage_without_selecting_City_Name() throws Throwable {
	   page.setAddress2("pune");
	   page.clickOnNext();
	}

	@Then("^'Please select city' message should display$")
	public void please_select_city_message_should_display() throws Throwable {
		String expectedMessage="Please select city";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		Thread.sleep(2000);
		driver.switchTo().alert().dismiss();
	}

	@When("^When user click on next in homepage without selecting State Name$")
	public void when_user_click_on_next_in_homepage_without_selecting_State_Name() throws Throwable {
	  page.setCity("Pune");
	  page.clickOnNext();
	}

	@Then("^'Please select state' message should display$")
	public void please_select_state_message_should_display() throws Throwable {
		String expectedMessage="Please select state";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		Thread.sleep(2000);
		driver.switchTo().alert().dismiss();
	}

	@When("^When user click on next in homepage without selecting MemeberShip status$")
	public void when_user_click_on_next_in_homepage_without_selecting_MemeberShip_status() throws Throwable {
	  page.setState("Maharashtra");
	  page.clickOnNext();
	}

	@Then("^'Please Select MemeberShip status' message should display$")
	public void please_Select_MemeberShip_status_message_should_display() throws Throwable {
		String expectedMessage="Please Select MemeberShip status";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		Thread.sleep(2000);
		driver.switchTo().alert().dismiss();
	}

	@When("^When user click on next in homepage with entering all valid details$")
	public void when_user_click_on_next_in_homepage_with_entering_all_valid_details() throws Throwable {
	    page.setMemberStatus("member");
	    page.clickOnNext();
	}

	@Then("^'Personal details are validated\\.' message should display$")
	public void personal_details_are_validated_message_should_display() throws Throwable {
		String expectedMessage="Personal details are validated.";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		Thread.sleep(2000);
		driver.switchTo().alert().dismiss();
	}

	@Then("^navigates to payment page$")
	public void navigates_to_payment_page() throws Throwable {
	   
	}

	@When("^When user navigates to payment page$")
	public void when_user_navigates_to_payment_page() throws Throwable {
	    
	}

	@Then("^Payment Page should load with title 'Payment Details'$")
	public void payment_Page_should_load_with_title_Payment_Details() throws Throwable {
		String expectedMessage="Payment Details";
		String actualMessage=driver.getTitle();
		Assert.assertEquals(expectedMessage, actualMessage);
	}

	@When("^When user is on payment page$")
	public void when_user_is_on_payment_page() throws Throwable {
	   
	}

	@When("^user click on Make payment without giving card holder name$")
	public void user_click_on_Make_payment_without_giving_card_holder_name() throws Throwable {
		page.paymentBtn();
	}

	@Then("^'Please fill the Card holder name' message should display$")
	public void please_fill_the_Card_holder_name_message_should_display() throws Throwable {
		String expectedMessage="Please fill the Card holder name";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		Thread.sleep(2000);
		driver.switchTo().alert().dismiss();
	}

	@When("^user click on Make payment without giving Card Holder Number$")
	public void user_click_on_Make_payment_without_giving_Card_Holder_Number() throws Throwable {
	    page.setHolderName("sharukh");
	    page.paymentBtn();
	}

	@Then("^'Please fill the Card holder number' message should display$")
	public void please_fill_the_Card_holder_number_message_should_display() throws Throwable {
		String expectedMessage="Please fill the Debit card Number";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		Thread.sleep(2000);
		driver.switchTo().alert().dismiss();
	}

	@When("^user click on Make payment without giving Expiration Month$")
	public void user_click_on_Make_payment_without_giving_Expiration_Month() throws Throwable {
	  page.setHolderNumber("987654789");
	  page.setCvv("3785");
	  page.paymentBtn();
	}

	@Then("^'Please fill expiration month' message should display$")
	public void please_fill_expiration_month_message_should_display() throws Throwable {
		String expectedMessage="Please fill expiration month";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		Thread.sleep(2000);
		driver.switchTo().alert().dismiss();
	}

	@When("^user click on Make payment without giving Expiration Year$")
	public void user_click_on_Make_payment_without_giving_Expiration_Year() throws Throwable {
	    page.setMonth("10");
	    page.paymentBtn();
	}

	@Then("^'Please fill expiration year' message should display$")
	public void please_fill_expiration_year_message_should_display() throws Throwable {
		String expectedMessage="Please fill the expiration year";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		Thread.sleep(2000);
		driver.switchTo().alert().dismiss();
	}

	@When("^user click on Make payment by giving all the valid deatils$")
	public void user_click_on_Make_payment_by_giving_all_the_valid_deatils() throws Throwable {
	    page.setYear("2010");
	    page.paymentBtn();
	}

	@Then("^'Conference Room Booking successfully done!!!' message should display$")
	public void conference_Room_Booking_successfully_done_message_should_display() throws Throwable {
		String expectedMessage="Conference Room Booking successfully done!!!";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		Thread.sleep(2000);
		
	}
	
}
